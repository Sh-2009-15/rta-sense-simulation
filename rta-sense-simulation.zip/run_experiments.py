import json, copy, csv
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import rta_sim as S

OUT = "/mnt/user-data/outputs/"
C = S.CENTRAL
SEEDS_MAIN, SEEDS_SWEEP = 20, 10
results = {}

def P(**kw):
    q = copy.deepcopy(C); q.update(kw); return q

def ms(v): return f"{v[0]:.3f} ± {v[1]:.3f}"

# ---------------------------------------------------------- 1. central scenario
central = S.run(C, SEEDS_MAIN)
results["central"] = central

# ---------------------------------------------------------- 2. sensor CV sweep
cvs = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30]
cv_rows = []
for cv in cvs:
    r1 = S.run(P(cv_sensor=cv), SEEDS_SWEEP)
    r2 = S.run(P(cv_sensor=cv, n_rep=2), SEEDS_SWEEP)
    cv_rows.append(dict(cv=cv,
        A=r1["A_fixed_sens@spec90"], B=r1["B_personal_sens@spec90"],
        B2=r2["B_personal_sens@spec90"],
        A_auc=r1["A_fixed_auc"], B_auc=r1["B_personal_auc"], B2_auc=r2["B_personal_auc"]))
results["cv_sweep"] = cv_rows

# ---------------------------------------------------------- 3. effect size x CV grid
fs = [2.0, 3.0, 4.0, 6.0]
grid = {}
for f in fs:
    grid[f] = [S.run(P(f=f, cv_sensor=cv), SEEDS_SWEEP)["B_personal_sens@spec90"][0] for cv in cvs]
results["grid_f_cv"] = {str(k): v for k, v in grid.items()}

# ---------------------------------------------------------- 4. biological variability
sw_rows = []
for sw in [0.20, 0.35, 0.50, 0.70]:
    r = S.run(P(sigma_w=sw), SEEDS_SWEEP)
    sw_rows.append(dict(sigma_w=sw, A=r["A_fixed_sens@spec90"], B=r["B_personal_sens@spec90"],
                        B_auc=r["B_personal_auc"], A_auc=r["A_fixed_auc"]))
results["sigma_w_sweep"] = sw_rows

# ---------------------------------------------------------- 5. regimen
reg = {}
for g in ["BID", "TID"]:
    r = S.run(P(regimen=g), SEEDS_SWEEP)
    reg[g] = dict(A=r["A_fixed_sens@spec90"], B=r["B_personal_sens@spec90"],
                  B_auc=r["B_personal_auc"], A_auc=r["A_fixed_auc"], prev=r["prevalence"])
results["regimen"] = reg

# ---------------------------------------------------------- 6. calibration length
cal_rows = []
for cd in [3, 5, 7, 10, 14, 21]:
    r = S.run(P(calib_days=cd), SEEDS_SWEEP)
    cal_rows.append(dict(calib_days=cd, B=r["B_personal_sens@spec90"], B_auc=r["B_personal_auc"]))
results["calibration"] = cal_rows

# ---------------------------------------------------------- objectives check
o1 = central["B_personal_sens@spec90"][0] >= 0.80
o2 = (central["B_personal_auc"][0] - central["A_fixed_auc"][0]) >= 0.10
ok_cv = [r["cv"] for r in cv_rows if r["B"][0] >= 0.80]
ok_cv2 = [r["cv"] for r in cv_rows if r["B2"][0] >= 0.80]
ok_cal = [r["calib_days"] for r in cal_rows if r["B"][0] >= 0.80]
results["objectives"] = dict(
    O1_met=bool(o1), O1_value=central["B_personal_sens@spec90"],
    O2_met=bool(o2), O2_delta=central["B_personal_auc"][0] - central["A_fixed_auc"][0],
    O3_max_cv_single=max(ok_cv) if ok_cv else None,
    O3_max_cv_duplicate=max(ok_cv2) if ok_cv2 else None,
    O4_min_calib_days=min(ok_cal) if ok_cal else None)
json.dump(results, open(OUT + "results.json", "w"), indent=1, default=float)

# ---------------------------------------------------------- figures
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})

# Fig 1: example child
rng = np.random.default_rng(7)
q = P(n_children=60, cv_sensor=0.10)
sim = S.simulate(q, rng)
nc = q["calib_days"]
# choose a child in the partial adherence class with a few misses
cand = [i for i in range(60) if sim["cls"][i] == 1 and sim["y"][i, nc:].sum() >= 3]
i = cand[0] if cand else 0
lnR = sim["lnR"][i]; y = sim["y"][i]
cal = lnR[:nc]; mu = cal.mean(); sd = max(cal.std(ddof=1), 0.15)
days = np.arange(len(lnR))
fig, ax = plt.subplots(figsize=(8, 4.4))
ax.axvspan(-0.5, nc - 0.5, color="#e8f0fe", label="Supervised calibration")
ax.plot(days, np.exp(lnR), "-o", ms=3.5, color="#555", lw=1, label="Measured Ca/Cit")
ax.axhline(np.exp(mu + q["k_z"] * sd), ls="--", color="#c0392b", label=f"Personal alarm threshold (z>{q['k_z']:.0f})")
ax.axhline(S.R_FIXED_THRESHOLD, ls=":", color="#888", label="Fixed population threshold (1.68)")
mm = np.where(y)[0]
ax.scatter(mm[mm >= nc], np.exp(lnR[mm[mm >= nc]]), s=60, facecolors="none", edgecolors="#c0392b", lw=1.6, label="True missed dose (previous night)")
ax.set_yscale("log"); ax.set_xlabel("Day"); ax.set_ylabel("Ca/Cit (mmol/mmol), log scale")
ax.set_title("Virtual child: morning Ca/Cit ratio vs. true missed doses")
ax.legend(fontsize=7.5, loc="upper center", bbox_to_anchor=(0.5, -0.18), ncol=3, frameon=False)
fig.tight_layout(); fig.savefig(OUT + "fig1_virtual_child.png", dpi=170); plt.close(fig)

# Fig 2: CV sweep
fig, ax = plt.subplots(figsize=(6.2, 4))
x = [r["cv"] * 100 for r in cv_rows]
for key, lab, col, mk in (("A", "Fixed threshold (A)", "#888", "s"),
                          ("B", "Personalised, 1 reading (B)", "#1f4e8c", "o"),
                          ("B2", "Personalised, duplicate reading (C)", "#2e8b57", "^")):
    y_ = [r[key][0] for r in cv_rows]; e_ = [r[key][1] for r in cv_rows]
    ax.errorbar(x, y_, yerr=e_, marker=mk, label=lab, color=col, capsize=2, lw=1.4)
ax.axhline(0.8, ls="--", color="#c0392b", lw=1); ax.text(x[-1], 0.81, "target 80 %", ha="right", color="#c0392b", fontsize=8)
ax.set_xlabel("Sensor error per analyte (CV, %)"); ax.set_ylabel("Sensitivity at 90 % specificity")
ax.set_ylim(0, 1); ax.set_title("How accurate must the sensor be?")
ax.legend(fontsize=8, frameon=False); fig.tight_layout(); fig.savefig(OUT + "fig2_sensor_cv.png", dpi=170); plt.close(fig)

# Fig 3: heatmap
fig, ax = plt.subplots(figsize=(6, 3.8))
M = np.array([grid[f] for f in fs])
im = ax.imshow(M, vmin=0, vmax=1, cmap="viridis", aspect="auto")
ax.set_xticks(range(len(cvs))); ax.set_xticklabels([f"{c*100:.0f}" for c in cvs])
ax.set_yticks(range(len(fs))); ax.set_yticklabels([f"×{f:g}" for f in fs])
for a in range(M.shape[0]):
    for b_ in range(M.shape[1]):
        ax.text(b_, a, f"{M[a,b_]:.2f}", ha="center", va="center", color="w" if M[a, b_] < 0.6 else "k", fontsize=8)
ax.set_xlabel("Sensor error per analyte (CV, %)"); ax.set_ylabel("Ca/Cit rise when dose is missed")
ax.set_title("Sensitivity at 90 % specificity (personalised method)")
fig.colorbar(im, ax=ax, shrink=0.85); fig.tight_layout(); fig.savefig(OUT + "fig3_effect_vs_sensor.png", dpi=170); plt.close(fig)

# Fig 4: calibration length
fig, ax = plt.subplots(figsize=(5.4, 3.6))
ax.plot([r["calib_days"] for r in cal_rows], [r["B"][0] for r in cal_rows], "-o", color="#1f4e8c")
ax.errorbar([r["calib_days"] for r in cal_rows], [r["B"][0] for r in cal_rows], yerr=[r["B"][1] for r in cal_rows], fmt="none", color="#1f4e8c", capsize=2)
ax.axhline(0.8, ls="--", color="#c0392b", lw=1)
ax.set_xlabel("Supervised calibration length (days)"); ax.set_ylabel("Sensitivity at 90 % specificity")
ax.set_ylim(0, 1); ax.set_title("Calibration period needed"); fig.tight_layout()
fig.savefig(OUT + "fig4_calibration.png", dpi=170); plt.close(fig)

# CSV summary
with open(OUT + "results_summary.csv", "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["experiment", "setting", "metric", "mean", "sd"])
    for k, v in central.items(): w.writerow(["central", "-", k, f"{v[0]:.4f}", f"{v[1]:.4f}"])
    for r in cv_rows:
        for m_ in ("A", "B", "B2"): w.writerow(["cv_sweep", f"CV={r['cv']}", m_ + "_sens@spec90", f"{r[m_][0]:.4f}", f"{r[m_][1]:.4f}"])
    for f in fs:
        for cv, v in zip(cvs, grid[f]): w.writerow(["effect_x_cv", f"f={f};CV={cv}", "B_sens@spec90", f"{v:.4f}", ""])
    for r in sw_rows:
        w.writerow(["sigma_w", r["sigma_w"], "A_sens@spec90", f"{r['A'][0]:.4f}", f"{r['A'][1]:.4f}"])
        w.writerow(["sigma_w", r["sigma_w"], "B_sens@spec90", f"{r['B'][0]:.4f}", f"{r['B'][1]:.4f}"])
    for g, r in reg.items():
        w.writerow(["regimen", g, "A_sens@spec90", f"{r['A'][0]:.4f}", f"{r['A'][1]:.4f}"])
        w.writerow(["regimen", g, "B_sens@spec90", f"{r['B'][0]:.4f}", f"{r['B'][1]:.4f}"])
    for r in cal_rows: w.writerow(["calibration", r["calib_days"], "B_sens@spec90", f"{r['B'][0]:.4f}", f"{r['B'][1]:.4f}"])
print(json.dumps(results["objectives"], indent=1, default=float))
print("central:")
for k, v in central.items(): print(f"  {k}: {ms(v)}")
print("cv sweep:")
for r in cv_rows: print(" ", r["cv"], "A", ms(r["A"]), "B", ms(r["B"]), "B2", ms(r["B2"]), "AUC B", ms(r["B_auc"]))
print("grid f x cv:")
for f in fs: print(" ", f, [round(v, 2) for v in grid[f]])
print("sigma_w:")
for r in sw_rows: print(" ", r["sigma_w"], "A", ms(r["A"]), "B", ms(r["B"]), "AUC B", ms(r["B_auc"]))
print("regimen:", {g: (ms(r["A"]), ms(r["B"]), ms(r["B_auc"]), ms(r["prev"])) for g, r in reg.items()})
print("calibration:")
for r in cal_rows: print(" ", r["calib_days"], ms(r["B"]), ms(r["B_auc"]))
