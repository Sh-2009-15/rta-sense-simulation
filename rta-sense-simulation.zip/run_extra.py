# -*- coding: utf-8 -*-
"""RTA-Sense: experiments added after review (7-10) + detection over ALL missed doses.
Run:  python3 run_extra.py      (about 2-3 minutes)  ->  results_v2.json
"""
import copy, json
import rta_sim as S

def keep(r):
    return {k: [float(v[0]), float(v[1])] for k, v in r.items() if isinstance(v, (list, tuple)) and len(v) == 2}

res = {}
res['central'] = keep(S.run(S.CENTRAL, 20))            # includes A2 (relative baseline) and overall detection
p = copy.deepcopy(S.CENTRAL); p['regimen'] = 'TID'
res['tid'] = keep(S.run(p, 10))                         # share of missed doses that is the last dose of the day
res['noise'] = {}                                       # experiment 8: heavy-tailed daily noise (same SD)
for df in (None, 5, 3):
    p = copy.deepcopy(S.CENTRAL); p['noise_df'] = df
    res['noise'][str(df)] = keep(S.run(p, 10))
res['rho'] = {}                                         # experiment 9: day-to-day autocorrelation AR(1)
for rho in (0.0, 0.3, 0.6):
    p = copy.deepcopy(S.CENTRAL); p['rho'] = rho
    res['rho'][str(rho)] = keep(S.run(p, 10))
res['sigma_b'] = {}                                     # experiment 7 (with A2 = experiment 10)
for sb in (0.0, 0.1, 0.2, 0.3, 0.5, 0.7):
    p = copy.deepcopy(S.CENTRAL); p['sigma_b'] = sb
    res['sigma_b'][str(sb)] = keep(S.run(p, 10))
json.dump(res, open('results_v2.json', 'w'), indent=1)
print('saved results_v2.json')
