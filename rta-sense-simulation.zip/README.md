# RTA-Sense: virtual laboratory (simulation code)

Simulation of home monitoring for children with distal renal tubular acidosis (dRTA):
detecting the missed dose that precedes a morning urine sample from the urinary calcium-to-citrate ratio.

## Environment used
Python 3.12.3, NumPy 2.4.4, Matplotlib 3.10.8, SciPy 1.17.1, Pillow 12.1.1

## Files
- `rta_sim.py`          simulation engine (child model, adherence, methods A, A2, B, C, metrics)
- `run_experiments.py`  experiments 1-6 and figures
- `run_extra.py`        experiments 7-10 (between-child variation, heavy-tailed noise, autocorrelation,
                        relative baseline A2) and detection over all missed doses
- `results_v2.json`     numbers quoted in the project

## Reproducibility
Random seeds are fixed: `numpy.random.default_rng(1000 + k)`, k = 0..19 (central scenario) or 0..9 (sensitivity runs).

## Important
All results are computer simulations with assumptions stated in the project form; they are not patient data.
