"""
RTA-Sense virtual lab: detecting a missed alkali dose in children with dRTA
from the time-resolved urinary calcium-to-citrate (Ca/Cit) ratio.

PRE-REGISTERED OBJECTIVES (fixed BEFORE running the experiments):
  O1  Personalised time-aware detector reaches sensitivity >= 80 % at
      specificity >= 90 % (per morning sample) in the central scenario.
  O2  Its AUC exceeds that of the single fixed-threshold method by >= 0.10.
  O3  Find the largest sensor CV (per analyte) at which O1 still holds.
  O4  Find the shortest supervised calibration period at which O1 holds.

All parameters are either taken from the literature (marked [ref]) or are
explicit ASSUMPTIONS that are swept in sensitivity analyses.
This is a simulation: NO real patient data are used.
"""
import numpy as np, json, sys

# ----------------------------------------------------------------- parameters
CENTRAL = dict(
    regimen="BID",        # BID: 08:00, 20:00 ; TID: 07:00, 15:00, 23:00
    f=3.0,                # fold-rise of Ca/Cit when treatment effect is gone
                          # [ref Song 2016: (548.4/280.0)*(216.0/156.5)=2.70]
    sigma_w=0.35,         # within-child day-to-day log-SD (ASSUMPTION, swept)
    sigma_b=0.50,         # between-child log-SD of covered baseline (ASSUMPTION)
    cv_sensor=0.10,       # per-analyte measurement CV (ASSUMPTION, swept;
                          # paper-based citrate assay RSD < 6.4 % [ref Janrod 2023])
    n_rep=1,              # replicate readings per sample
    calib_days=14,        # supervised calibration days
    monitor_days=28,
    n_children=400,
    k_z=2.0,              # alarm if z > k_z
    noise_df=None,        # None = Gaussian daily noise; else Student-t df (same SD)
    rho=0.0,              # day-to-day autocorrelation of the daily noise (AR(1))
)
R_COVERED_MEDIAN = 0.81     # mmol/mmol, normocalciuric stone-free children [Donger 2026]
R_FIXED_THRESHOLD = 1.68    # mmol/mmol, upper quartile of the same reference [Donger 2026]
DUR_MEAN, DUR_SD = 12.0, 1.5   # h, duration of citraturic effect [label, ref 6]
TAU = 3.0                   # h, decay time after effect ends (ASSUMPTION)
RAMP = 1.0                  # h, onset of effect [label]
SCHEDULE = {"BID": [8.0, 20.0], "TID": [7.0, 15.0, 23.0]}
# adherence classes anchored to ISPOR 2021 cohort (62 / 17 / 21 %)  [ref 5]
ADH_CLASSES = [(0.62, 0.02, 0.10), (0.17, 0.10, 0.25), (0.21, 0.26, 0.50)]
NIGHT_MULT = 1.5            # last dose of the day is missed more often (ASSUMPTION)


def auc_rank(score, y):
    """AUC via Mann-Whitney U (ties handled by average ranks)."""
    score = np.asarray(score); y = np.asarray(y).astype(bool)
    n1, n0 = y.sum(), (~y).sum()
    if n1 == 0 or n0 == 0:
        return np.nan
    order = np.argsort(score, kind="mergesort")
    ranks = np.empty(len(score)); ranks[order] = np.arange(1, len(score) + 1)
    # average ties
    s_sorted = score[order]
    i = 0
    while i < len(s_sorted):
        j = i
        while j + 1 < len(s_sorted) and s_sorted[j + 1] == s_sorted[i]:
            j += 1
        if j > i:
            ranks[order[i:j + 1]] = (i + j) / 2 + 1
        i = j + 1
    return (ranks[y].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)


def sens_at_spec(score, y, spec=0.90):
    y = np.asarray(y).astype(bool)
    thr = np.quantile(np.asarray(score)[~y], spec)
    return float((np.asarray(score)[y] > thr).mean()), float(thr)


def simulate(p, rng):
    N = p["n_children"]; sched = np.array(SCHEDULE[p["regimen"]]); m = len(sched)
    days = np.arange(-1, p["calib_days"] + p["monitor_days"])   # day -1 = warm-up
    nd = len(days)
    # per-child traits
    b = rng.normal(0, p["sigma_b"], N)
    D = np.clip(rng.normal(DUR_MEAN, DUR_SD, N), 8, 16)
    cls = rng.choice(3, N, p=[c[0] for c in ADH_CLASSES])
    pm = np.array([rng.uniform(ADH_CLASSES[c][1], ADH_CLASSES[c][2]) for c in cls])
    # dose-taking matrix [N, nd, m]
    miss_p = np.repeat(pm[:, None, None], nd, 1).repeat(m, 2)
    miss_p[:, :, m - 1] = np.minimum(miss_p[:, :, m - 1] * NIGHT_MULT, 0.85)
    taken = rng.random((N, nd, m)) > miss_p
    taken[:, days < p["calib_days"], :] = True            # supervised calibration
    # dose times (absolute hours, day d at 24*d)
    t_dose = (days[:, None] * 24.0 + sched[None, :])        # [nd, m]
    flat_t = t_dose.reshape(-1); flat_taken = taken.reshape(N, -1)
    # morning samples on days >= 0, shortly before first scheduled dose
    sdays = days[days >= 0]
    jit = np.clip(rng.normal(-0.25, 0.33, (N, len(sdays))), -1.5, -0.08)
    ts = sdays[None, :] * 24.0 + sched[0] + jit            # [N, ns]
    # treatment effect E at sample time
    E = np.zeros_like(ts)
    for j in range(flat_t.size):
        s = ts - flat_t[j]
        mask = (s >= 0) & (s < 60)
        if not mask.any():
            continue
        Dj = np.broadcast_to(D[:, None], ts.shape)
        k = np.where(s < RAMP, s / RAMP, np.where(s <= Dj, 1.0, np.exp(-(s - Dj) / TAU)))
        E += np.where(mask, k, 0.0) * flat_taken[:, j][:, None]
    E = np.minimum(E, 1.0)
    # truth: was the dose immediately preceding the sample missed?
    prev_missed = ~taken[:, :-1, m - 1]                    # day d-1 last dose, d>=0
    prev_missed = prev_missed[:, :len(sdays)]
    # observed ln ratio
    mu = np.log(R_COVERED_MEDIAN) + b[:, None] + (1 - E) * np.log(p["f"])
    if p.get("noise_df") is None and p.get("rho", 0.0) == 0.0:
        bio = rng.normal(0, p["sigma_w"], mu.shape)
    else:
        df = p.get("noise_df"); rho = p.get("rho", 0.0)
        z = rng.normal(size=mu.shape) if df is None else rng.standard_t(df, size=mu.shape) / np.sqrt(df / (df - 2))
        e = np.empty_like(z); e[:, 0] = z[:, 0]
        for j in range(1, z.shape[1]):
            e[:, j] = rho * e[:, j - 1] + np.sqrt(1 - rho ** 2) * z[:, j]
        bio = p["sigma_w"] * e
    s_ln = np.sqrt(np.log(1 + p["cv_sensor"] ** 2))         # per analyte
    sens_err = rng.normal(0, np.sqrt(2) * s_ln / np.sqrt(p["n_rep"]), mu.shape)
    lnR = mu + bio + sens_err
    return dict(lnR=lnR, y=prev_missed, E=E, ts=ts, cls=cls, b=b, taken=taken,
                sdays=sdays)


def evaluate(sim, p):
    lnR, y = sim["lnR"], sim["y"]
    nc = p["calib_days"]
    cal, mon = lnR[:, :nc], lnR[:, nc:]
    ym = y[:, nc:]
    # Method A: single fixed population threshold on raw ratio (no time, no person)
    scoreA = mon
    # Method B: personalised z-score against the child's own calibration
    mu_i = cal.mean(1, keepdims=True)
    sd_i = np.maximum(cal.std(1, ddof=1, keepdims=True), 0.15)
    scoreB = (mon - mu_i) / sd_i
    scoreA2 = mon - mu_i                      # relative personal baseline, no variance scaling
    out = {}
    yy = ym.ravel()
    for name, sc in (("A_fixed", scoreA), ("A2_relative", scoreA2), ("B_personal", scoreB)):
        sc = sc.ravel()
        out[name + "_auc"] = auc_rank(sc, yy)
        se, _ = sens_at_spec(sc, yy, 0.90)
        out[name + "_sens@spec90"] = se
    # practical fixed rules
    flagA = (scoreA > np.log(R_FIXED_THRESHOLD)).ravel()
    flagB = (scoreB > p["k_z"]).ravel()
    for name, fl in (("A_rule", flagA), ("B_rule", flagB)):
        tp = (fl & yy).sum(); fn = (~fl & yy).sum()
        tn = (~fl & ~yy).sum(); fp = (fl & ~yy).sum()
        out[name + "_sens"] = tp / max(tp + fn, 1)
        out[name + "_spec"] = tn / max(tn + fp, 1)
        out[name + "_ppv"] = tp / max(tp + fp, 1)
    out["prevalence"] = float(yy.mean())
    # detection over ALL missed doses (night + other doses) in the monitoring window
    m = sim["taken"].shape[2]
    miss = ~sim["taken"][:, nc + 1: nc + p["monitor_days"], :]
    all_missed = miss.sum(); night_missed = miss[:, :, m - 1].sum()
    out["frac_last_dose"] = float(night_missed / max(all_missed, 1))
    out["overall_sens_rule"] = float((flagB & yy).sum() / max(all_missed, 1))
    out["overall_sens90"] = out["B_personal_sens@spec90"] * out["frac_last_dose"]
    return out


def run(p, seeds, base_seed=1000):
    res = []
    for s in range(seeds):
        rng = np.random.default_rng(base_seed + s)
        res.append(evaluate(simulate(p, rng), p))
    keys = res[0].keys()
    return {k: (float(np.nanmean([r[k] for r in res])),
                float(np.nanstd([r[k] for r in res], ddof=1))) for k in keys}


if __name__ == "__main__":
    r = run(CENTRAL, 5)
    print(json.dumps(r, indent=1))
